#include "InputOutput.hpp"
#include "City.hpp"

using namespace std;

//Display a title message at the begin of the program.
void displayTitle() {
	cout << "\nTRAVELLING SALESMAN PROBLEM\n";
	cout << "Project Group 36\n";
	cout << "Bao Chau, John Costello, Sarah Walter\n";
	cout << "=========================================\n\n";
}

//Display an end message at the end of the program.
void displayEndMsg() {
	cout << "\nThank you for using the program. Good Bye!\n\n";
}


//Read cities from input file and return result as a vector of cities.
void readCitiesFromFile(ifstream &inFile, vector<City*> *cities) {
	int a, b, c;

	while (inFile >> a >> b >> c) {
		City *p = new City(a, b, c);
		cities->push_back(p);
	}
}

//Clean up memory used from cities.
void deleteCities(vector<City*> cities) {
	for (int i = 0; i < (int)cities.size(); i++)
	{
		delete(cities[i]);
	}
	cities.clear();
}

//Open the input and output file. Return false if unable
//to open any file.
bool openFiles(ifstream &inFile, ofstream &outFile, char *fileName)
{
	bool done = false, status = false;
	string inFileName = fileName;
	string outFileName = inFileName + ".tour";

	inFile.open(inFileName);
	if (inFile.fail()) {
		cout << "\nUnable to open the \"";
		cout << inFileName;
		cout << "\" file for data reading.\n";
		cout << "Please check your command line input and try again.\n";
		return false;
	}

	outFile.open(inFileName + ".tour");
	if (outFile.fail())
	{
		//Create new prompt message.
		cout << "\nUnable to create the \"";
		cout << inFileName;
		cout << ".tour\" file for data output.\n";
		cout << "Please check your command line input and try again.\n";
		return false;
	}
	
	return true;
}
